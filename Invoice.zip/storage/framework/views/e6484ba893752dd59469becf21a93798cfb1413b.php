<?php
    $balance_transections = App\Models\Transection::where('ledger_id', $id)->get();

    $debit = 0;
    $credit = 0;
    $balance = 0;
    foreach ($balance_transections as $transection) {
        $debit += $transection->debit;
        $credit += $transection->credit;
        $balance = $debit - $credit;
    }
    $balance = number_format($balance, 2, '.', ',');
    $debit = number_format($debit, 2, '.', ',');
    $credit = number_format($credit, 2, '.', ',');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e($ledgers->name); ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css"
        integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <style>
        table th {
            font-size: 12px !important;
            font-weight: 600 !important;
        }

        table td {
            padding: 0px 5px !important;
            font-size: 11px !important;
        }

        table thead tr th {
            padding: 0 5px 2px !important
        }

        .customer_info td {
            margin-left: 15px
        }

        .clr {
            clear: both;
        }

        .table {
            margin-bottom: 8px !important
        }
    </style>
</head>



<body style="width: 100%; padding:0px; margin:0px">

    <p style="font-weight: 800; font-size: 22px; margin-bottom: 0px">M/S R.K. TRADING</p>
    <p style="font-weight: 700; font-size: 15px; margin-bottom: 0px">IMPORTER, EXPORTER & GENERAL MERCHANT</p>
    <p style="font-weight: 500; font-size: 16px; margin-bottom: 0px">DHARANDA, DINAJPUR ROAD, BANGL HILI, HAKIMPUR, DINAJPUR, BANGLADESH.</p>
    <p style="font-weight: 400; font-size: 15px; margin-bottom: 0px">Phone: 01711-413307 - 01711286437</p>
    <p style="font-weight: 400; font-size: 15px; margin-bottom: 0px">Email: <a href="rktrading65@yahoo.com" style="text-decoration: none; color: #444444">rktrading65@yahoo.com</a></p>

    <br>
    <p style="font-weight: 400; font-size: 15px; margin-bottom: 5px">M/S H R ROSHID</p>
    <p style="font-weight: 400; font-size: 15px; margin-bottom: 5px">
        Party's report: <?php echo e($type); ?>

        <?php if($from != null): ?>

        <span class="ml-3">Form: ( <?php echo e($from); ?> ) &nbsp;&nbsp; To: ( <?php echo e($to); ?> )</span>

        <?php endif; ?>
    </p>
    <p style="font-weight: 400; font-size: 15px;">Party's Report Created: <?= date('l jS \of F Y h:i:s A'); ?></p>
    <table class="table table-bordered mb-5">
        <thead class="bg-success">
            <tr>
                <th scope="col">Entry date</th>
                <th scope="col">Information</th>
                <th scope="col">Debit</th>
                <th scope="col">Credit</th>
                <th scope="col">Calan</th>
                <th scope="col">Bank/Cheque</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $transections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $invoic_items = DB::table('invoice_items')
                        ->where('transection_id', $transection->id)
                        ->get();
                ?>



                <?php $__currentLoopData = $invoic_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $total_balance += $items->price;
                    ?>
                    <tr>

                        <td><?php echo e($transection->entry_date); ?></td>
                        <td>

                            <b><?php echo e($items->item); ?> </b>
                            <b><?php echo e($items->size); ?></b>
                            (W)
                            : <b><?php echo e($items->width); ?></b>
                            (H): <b><?php echo e($items->height); ?></b>
                            (SQft): <b><?php echo e($items->square_ft); ?></b>
                            <br>

                            (PCS): <b><?php echo e($items->qty); ?></b>
                            (Total SQft): <b><?php echo e($items->total_square_ft); ?></b>
                            (Rate): <b><?php echo e($items->rate); ?></b>


                        </td>

                        <td><?php echo e(number_format($items->price, 2, '.', ',')); ?></td>
                        <td>0</td>
                        <td><?php echo e($transection->calan); ?></td>
                        <td>-</td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php

                    $total_balance -= $transection->credit;

                ?>



                <tr>

                    <td><?php echo e($transection->entry_date); ?></td>
                    <td>PAYMENT</td>
                    <td> 0 </td>
                    <td><?= number_format($transection->credit, 2, '.', ',') ?></td>
                    <td><?php echo e($transection->note); ?></td>

                    <td><?php echo e($transection->bank_name); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td colspan="2"><span class="float-right font-weight-bold">Total:</span></td>
                <td class=" font-weight-bold"><?php echo e($debit); ?></td>
                <td class=" font-weight-bold"><?php echo e($credit); ?></td>
            </tr>
            <tr>
                <td colspan="6" class="text-center">Balance: <?php echo e($balance); ?></td>
            </tr>
        </tbody>
    </table>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\1New folder\Invoice\resources\views/supplier_pdf.blade.php ENDPATH**/ ?>