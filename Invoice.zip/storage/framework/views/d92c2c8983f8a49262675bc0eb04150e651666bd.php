<?php
    $active = 'purchase';
?>

<?php $__env->startSection('title'); ?>
    Edit Purchase
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="main-body">
        <div class="container body_content">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="text-dark"><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>
            <form action="<?php echo e(url('edit-purchase/' . $transections->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-3 offset-2 d-flex">
                        <label for="datepicker" class="pt-2 mr-2">Date:</label>
                        <input type="text" class="datepicker" name="entry_date" class="form-control"
                            value="<?php echo e($transections->entry_date); ?>">
                    </div>
                    <div class="col-4" id="search_dropdown">
                        <select data-live-search="true" class="w-100" name="ledger_id">
                            <?php $__currentLoopData = App\Models\Ledger::where('type', 1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option data-tokens="<?php echo e($customer->id); ?>" value="<?php echo e($customer->id); ?>"
                                    <?php echo e(!empty($transections->getCustomer->name) && $customer->name == $transections->getCustomer->name ? 'selected' : ''); ?>>
                                    <?php echo e($customer->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                    </div>
                </div>
                <hr class="mt-4">
                <div id="body-table">
                    <table class="table table-bordered table-striped">
                        <thead class="table_head">
                            <tr>
                                <th scope="col">Item</th>
                                <th scope="col">Size</th>
                                <th scope="col">Width</th>
                                <th scope="col">Height</th>
                                <th scope="col">Square ft</th>
                                <th scope="col">Quantity</th>
                                <th scope="col">Total Square</th>
                                <th scope="col">Rate</th>
                                <th scope="col">Price</th>
                                <th scope="col">
                                    <button class="btn btn-primary" id="add_invoice" style="padding: 2px 8px">
                                        <i class="fa-solid fa-plus"></i>
                                    </button>
                                </th>
                            </tr>
                        </thead>
                        <tbody id="table_body">
                            <?php $__currentLoopData = $transections->getInvoiceItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr id="TableRow">
                                    <td>
                                        <input type="text" class="form-control" name="item[]"
                                            value="<?php echo e($item->item); ?>" required>
                                    </td>
                                    <td>
                                        <input type="text" class="form-control" name="size[]"
                                            value="<?php echo e($item->size); ?>" required>
                                    </td>
                                    <td>
                                        <input type="text" class="form-control width" name="width[]"
                                            value="<?php echo e($item->width); ?>" required>
                                    </td>
                                    <td>
                                        <input type="text" class="form-control height" name="height[]"
                                            value="<?php echo e($item->height); ?>" required>
                                    </td>
                                    <td>
                                        <input type="text" class="form-control square_ft" name="square_ft[]"
                                            value="<?php echo e($item->square_ft); ?>" readonly required>
                                    </td>
                                    <td>
                                        <input type="text" class="form-control qty" name="qty[]"
                                            value="<?php echo e($item->qty); ?>" required>
                                    </td>
                                    <td>
                                        <input type="text" class="form-control total_square_ft" name="total_square_ft[]"
                                            value="<?php echo e($item->total_square_ft); ?>" readonly required>
                                    </td>
                                    <td>
                                        <input type="text" class="form-control rate" name="rate[]"
                                            value="<?php echo e($item->rate); ?>" required>
                                    </td>
                                    <td>
                                        <input type="text" class="form-control price" name="price[]"
                                            value="<?php echo e($item->price); ?>" readonly required>
                                    </td>
                                    <td>
                                        <button class="btn btn-danger mt-2" id="remove_invoice_row"><i
                                                class="fa-solid fa-trash"></i></button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                

                <table class="float-right fix-invoice-table">
                    <tr>
                        <th>SubTotal: </th>
                        <td>
                            <input class="form-control" type="text" id="subtotal" name="subtotal" placeholder="SubTotal"
                                readonly value="<?php echo e($transections->debit); ?>">
                        </td>
                    </tr>
                    <tr>
                        <th>Paid: </th>
                        <td>
                            <input class="form-control" type="text" id="credit" name="credit" placeholder="Paid"
                                value="<?php echo e($transections->credit); ?>">
                        </td>
                    </tr>
                    <tr>
                        <th>Cheque: </th>
                        <td>
                            <input type="text" class="form-control" placeholder="Enter Cheque" name="cheque"
                                value="<?php echo e($transections->note); ?>">
                        </td>
                    </tr>

                    <tr>
                        <th>Calan: </th>
                        <td>
                            <input type="text" class="form-control" placeholder="Enter Calan" name="calan"
                                value="<?php echo e($transections->calan); ?>">
                        </td>
                    </tr>
                    <tr>
                        <th>Bank: </th>
                        
                        <td class="bank_td">
                            <input type="text" class="form-control" name="bank_name" id="bank_name"
                                placeholder="Enter Bank" value="<?php echo e($transections->bank_name); ?>">
                            <div id="search_bank_name">
                            </div>
                        </td>
                    </tr>
                </table>
                <div class="clr"></div>
                <button class="float-right mb-5 mr-1 btn btn-success" style="width: 305px"
                    id="save_invoice">Save</button>
                <div class="clr"></div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\1New folder\Invoice\resources\views/edit_c_purchase.blade.php ENDPATH**/ ?>