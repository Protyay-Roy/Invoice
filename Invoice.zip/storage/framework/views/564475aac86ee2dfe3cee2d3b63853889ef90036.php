<?php $__currentLoopData = $bank_transections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        if (!empty($transection->debit) || $transection->debit != 0) {
            $total_balance += $transection->debit;
        }
        if (!empty($transection->credit) || $transection->credit != 0) {
            $total_balance -= $transection->credit;
        }
    ?>
    <tr>
        <td><?php echo e($transection->entry_date); ?></td>
        <td><?php echo e($transection->type); ?></td>
        <td><?= number_format($transection->debit, 2, '.', ',') ?></td>
        <td><?= number_format($transection->credit, 2, '.', ',') ?></td>
        <td><?php echo e(number_format($total_balance, 2, '.', ',')); ?></td>
        <td><?php echo e($transection->note); ?></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\1New folder\Invoice\resources\views/view_bank_transection.blade.php ENDPATH**/ ?>