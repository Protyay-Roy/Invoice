<?php
    $active = 'daily_entry';
?>

<?php $__env->startSection('title'); ?>
    Create Daily Entry
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="main-body">
        <div class="container body_content">
            <?php if(Session::has('success_message')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong>Success:</strong> <?php echo e(Session('success_message')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>
            <?php if(Session::has('error_message')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <strong>Error:</strong> <?php echo e(Session('error_message')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>
            <form action="<?php echo e(route('add-edit-daily_entry')); ?>" method="post" id="entry_form">
                <?php echo csrf_field(); ?>
                <div id="body-table">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                    <table class="table table-bordered table-striped">
                        <thead class="table_head" style="text-transform: uppercase">
                            <tr>
                                <th scope="col">Date</th>
                                <th scope="col">Type</th>
                                <th scope="col">Profile</th>
                                <th scope="col">Debit</th>
                                <th scope="col">Credit</th>
                                <th scope="col">Cheque</th>
                                <th scope="col">Bank</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody id="table_body">
                            <tr id="TableRow">
                                <td>
                                    <input type="text" value="<?php echo e(date('Y-m-d')); ?>" id="datepicker"
                                        class="form-control datepicker" name="date[]" required>
                                </td>
                                <td>
                                    <select name="type[]" class="form-control entry_type" required>
                                        <option selected disabled value="">Select payment type</option>
                                        <option value="customer">Customer Payment</option>
                                        <option value="supplier">Supplier Payment</option>
                                        <option value="bank">Bank Payment</option>
                                    </select>
                                </td>
                                <div id="ajax_profile">
                                    <td>
                                        <select name="profile[]" class="form-control profile" required>
                                            <option selected disabled value="">Select profile</option>
                                        </select>
                                    </td>
                                </div>

                                <td>
                                    <input type="text" class="form-control" name="debit[]" placeholder="Debit">
                                </td>
                                <td>
                                    <input type="text" class="form-control" name="credit[]" placeholder="Credit">
                                </td>
                                <td>
                                    <input type="text" class="form-control" name="note[]" placeholder="Cheque">
                                </td>

                                

                                <td>
                                    <input type="text" class="form-control" name="bank_name[]" placeholder="Bank">
                                </td>

                                    
                                <td>
                                    <button class="btn btn-primary mt-1" id="add_entry">
                                        <i class="fa-solid fa-plus"></i>
                                    </button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <button class="btn btn-success float-right mb-5" id="save">Save</button>
                <div class="clr"></div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\1New folder\Invoice\resources\views/create_daily_entry.blade.php ENDPATH**/ ?>