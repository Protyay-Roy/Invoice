<?php $__env->startSection('title'); ?>
    Bank List
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="body-top">
        <div class="container">
            <div class="row">
                <div class="col-6 offset-3">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="text-dark"><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-md-7 col-sm-12 mx-auto">
                    <div class="body-top-content">
                        <ul>
                            <li> <a href="#">All Bank</a> </li>
                            <li> <a href="#">Active Bank</a>  </li>
                            <li> <a href="#">Inactive Bank</a> </li>
                            <li>
                                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
                                    Add Bank
                                </button>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <!--bank add Modal -->
            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Add Bank Details</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form action="<?php echo e(url('/create-bank')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="modal-body">
                                <div class="mb-3">
                                    <label for="name" class="form-label">Bank Name:</label>
                                    <input type="text" class="form-control" placeholder="Enter bank name" name="name" required>
                                </div>
                                <div class="mb-3">
                                    <label for="account_number" class="form-label">Account number:</label>
                                    <input type="text" class="form-control" placeholder="Enter account number"
                                        name="account_number" required>
                                </div>
                                <div class="mb-3">
                                    <label for="branch" class="form-label">Branch:</label>
                                    <input type="text" class="form-control" placeholder="Enter branch" name="branch" required>
                                </div>
                                
                                <div class="mb-3">
                                    <div class="row">
                                        <div class="col-6">
                                            <label for="debit" class="form-label">Debit:</label>
                                            <input type="text" class="form-control" placeholder="Enter debit"
                                                name="debit">
                                        </div>
                                        <div class="col-6">
                                            <label for="credit" class="form-label">Credit:</label>
                                            <input type="text" class="form-control" placeholder="Enter credit"
                                                name="credit">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                <input type="submit" value="Save" class="btn btn-success" style="box-shadow: none">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!--bank update/edit Modal -->
            <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Edit & Update Bank Details</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form action="<?php echo e(url('/create-bank')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="update_id" id="bank_id" value="">
                            <div class="modal-body">
                                <div class="mb-3">
                                    <label for="name" class="form-label">Bank Name:</label>
                                    <input type="text" class="form-control" placeholder="Enter bank name"
                                        name="name" id="name" required>
                                </div>
                                <div class="mb-3">
                                    <label for="account_number" class="form-label">Account number:</label>
                                    <input type="text" class="form-control" placeholder="Enter account number"
                                        name="account_number" id="account_number" required>
                                </div>
                                <div class="mb-3">
                                    <label for="branch" class="form-label">Branch:</label>
                                    <input type="text" class="form-control" placeholder="Enter branch" name="branch"
                                        id="branch" required>
                                </div>
                                
                                <div class="mb-3">
                                    <div class="row">
                                        <div class="col-6">
                                            <label for="debit" class="form-label">Debit:</label>
                                            <input type="text" class="form-control" id="debit"
                                                placeholder="Enter debit" name="debit">
                                        </div>
                                        <div class="col-6">
                                            <label for="credit" class="form-label">Credit:</label>
                                            <input type="text" class="form-control" id="credit"
                                                placeholder="Enter credit" name="credit">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                <input type="submit" value="Update" class="btn btn-success" style="box-shadow: none">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="main-body">
        <div class="container body_content" style="margin-top: -25px;">
            <?php if(Session::has('success_message')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong>Success:</strong> <?php echo e(Session('success_message')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="text-dark"><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>
            
            <div>
                <table id="example" class="table table-striped table-bordered" style="width:100%">
                    <thead>
                        <tr>
                            <th scope="col">Bank Name</th>
                            <th scope="col">Account Number</th>
                            <th scope="col">Branch</th>
                            
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = App\Models\Bank::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <a href="<?php echo e(url('view-bank/'.$bank->id)); ?>"><?php echo e($bank->name); ?></a>
                                </td>
                                <td><?php echo e($bank->account_number); ?></td>
                                <td><?php echo e($bank->branch); ?></td>
                                
                                <td>
                                    <button class="btn btn-success" id="view_bank"
                                        value="<?php echo e($bank->id); ?>" title="View Bank"><i class="fa-regular fa-eye"></i></button>
                                    <button class="btn btn-info ml-1" id="edit_bank"
                                        value="<?php echo e($bank->id); ?>" title="Edit Bank"><i class="fa-solid fa-pencil"></i></button>
                                    <button class="btn btn-danger ml-1" id="delete_bank"
                                        value="<?php echo e($bank->id); ?>" title="Delete Bank"><i class="fa-solid fa-trash"></i></button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\1New folder\Invoice-old\resources\views/bank.blade.php ENDPATH**/ ?>