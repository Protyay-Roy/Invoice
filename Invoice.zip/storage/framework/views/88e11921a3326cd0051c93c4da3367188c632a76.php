


<?php $__currentLoopData = $transections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        if (!empty($transection->debit) || $transection->debit != 0) {
            $total_balance += $transection->debit;
        }
        if (!empty($transection->credit) || $transection->credit != 0) {
            $total_balance -= $transection->credit;
        }
    ?>
    <tr>
        <td><?php echo e($transection->entry_date); ?></td>
        <td><?php echo e($transection->type); ?></td>
        
        <td><?= number_format($transection->debit, 2, '.', ',') ?></td>
        <td><?= number_format($transection->credit, 2, '.', ',') ?></td>
        <td><?php echo e(number_format($total_balance, 2, '.', ',')); ?></td>
        <td><?php echo e($transection->note); ?></td>
        <td><?php echo e($transection->calan); ?></td>
        <td><?php echo e($transection->bank_name); ?></td>
        <?php if($transection->type == 'INVOICE' && $status == 'view'): ?>
            <td>
                <button class="btn btn-success" id="view_invoice" value="<?php echo e($transection->id); ?>" title="View"><i
                        class="fa-regular fa-eye"></i></button>
                <a href="<?php echo e(url('edit-invoice/' . $transection->id)); ?>" class="btn btn-info ml-1" title="Edit"><i
                        class="fa-solid fa-pencil"></i></a>
                <button value="<?php echo e($transection->id); ?>" id="delete_invoice" class="btn btn-danger ml-1"
                    title="Delete"><i class="fa-solid fa-trash"></i></button>
            </td>
        <?php elseif($transection->type == 'PAYMENT' && $status == 'view'): ?>
            <td>
                <button class="btn btn-success" id="view_invoice" value="<?php echo e($transection->id); ?>" title="View"
                    disabled><i class="fa-regular fa-eye"></i></button>
                <a href="<?php echo e(url('edit-daily_entry/' . $transection->id)); ?>" class="btn btn-info ml-1"
                    title="Edit"><i class="fa-solid fa-pencil"></i></a>
                <button value="<?php echo e($transection->id); ?>" id="delete_entry" class="btn btn-danger ml-1"
                    title="Delete"><i class="fa-solid fa-trash"></i></button>
            </td>
        <?php elseif($transection->type == 'OPENING BALANCE' && $status == 'view'): ?>
            <td>
                <button class="btn btn-success" id="view_invoice" value="<?php echo e($transection->id); ?>" title="View"
                    disabled><i class="fa-regular fa-eye"></i></button>

                
                <button class="btn btn-info ml-1" id="edit_supplier" value="<?php echo e($transection->ledger_id); ?>"
                    title="Edit Supplier" disabled><i class="fa-solid fa-pencil"></i></button>

                <button value="<?php echo e($transection->id); ?>" id="delete_entry" class="btn btn-danger ml-1" title="Delete"
                    disabled><i class="fa-solid fa-trash"></i></button>
            </td>
        <?php endif; ?>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\1New folder\Invoice-old\resources\views/view_transection.blade.php ENDPATH**/ ?>