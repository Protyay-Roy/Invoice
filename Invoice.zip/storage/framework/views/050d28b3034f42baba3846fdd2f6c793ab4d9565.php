<?php
    $active = 'daily_entry';
?>

<?php $__env->startSection('title'); ?>
    Edit Daily Entry
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="main-body">
        <div class="container body_content">
            <?php if(Session::has('success_message')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong>Success:</strong> <?php echo e(Session('success_message')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>
            <form action="<?php echo e(route('edit-entry', $transection->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div id="body-table">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                    <table class="table table-bordered table-striped">
                        <thead class="table_head" style="text-transform: uppercase">
                            <tr>
                                <th scope="col">Date</th>
                                <th scope="col">Type</th>
                                <th scope="col">Profile</th>
                                <th scope="col">Debit</th>
                                <th scope="col">Credit</th>
                                <th scope="col">Cheque</th>
                                <th scope="col">Bank</th>
                            </tr>
                        </thead>
                        <tbody id="table_body">
                            <tr id="TableRow">
                                <td>
                                    <input type="text" class="form-control datepicker" name="date" id="datepicker"
                                        value="<?php echo e($transection->entry_date); ?>" required>
                                    <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </td>
                                <td>
                                    <select name="type" class="form-control entry_type" required>
                                        <option selected disabled value="">Select payment type</option>
                                        <option value="customer" <?php echo e($transection->getCustomer->type == 1 ? 'selected' : ''); ?>>Customer Payment</option>
                                        <option value="supplier" <?php echo e($transection->getCustomer->type == 2 ? 'selected' : ''); ?>>Supplier Payment</option>
                                        <option value="bank">Bank Payment</option>
                                    </select>
                                    <?php $__errorArgs = ['entry_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </td>
                                <td>
                                    <select name="profile" class="form-control profile" required>
                                        <option selected disabled value=""> Select Profile</option>
                                        <option selected value="<?php echo e($transection->getCustomer->id); ?>"> <?php echo e($transection->getCustomer->name); ?></option>
                                    </select>
                                </td>
                                <td>
                                    <input type="text" class="form-control" name="debit" placeholder="Debit"
                                        value="<?php echo e($transection->debit); ?>">
                                </td>
                                <td>
                                    <input type="text" class="form-control" name="credit" placeholder="Credit"
                                        value="<?php echo e($transection->credit); ?>">
                                </td>
                                <td>
                                    <input type="text" class="form-control" name="note" placeholder="Cheque"
                                        value="<?php echo e($transection->note == 'N/A' ? '' : $transection->note); ?>">
                                </td>
                                <td>
                                    <select name="bank_name" id="bank_name" class="form-control">
                                        <option selected disabled>Select your bank</option>
                                        <?php $__currentLoopData = App\Models\Bank::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option
                                                <?php echo e(!empty($transection->bank_name) && $transection->bank_name == $bank->name ? 'selected' : ''); ?>

                                                value="<?php echo e($bank->name); ?>"><?php echo e($bank->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <button class="btn btn-success float-right mb-5">Save</button>
                <div class="clr"></div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\1New folder\Invoice\resources\views/edit_daily_entry.blade.php ENDPATH**/ ?>