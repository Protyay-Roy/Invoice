

<?php $__currentLoopData = $transections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $invoic_items = DB::table('invoice_items')
            ->where('transection_id', $transection->id)
            ->get();
    ?>



    <?php $__currentLoopData = $invoic_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $total_balance += $items->price;
        ?>
        <tr>

            <td><?php echo e($transection->entry_date); ?></td>
            <td>

                <b><?php echo e($items->item); ?> </b>
                <b><?php echo e($items->size); ?></b>
                (W)
                : <b><?php echo e($items->width); ?></b>
                (H): <b><?php echo e($items->height); ?></b>
                (SQft): <b><?php echo e($items->square_ft); ?></b>
                <br>

                (PCS): <b><?php echo e($items->qty); ?></b>
                (Total SQft): <b><?php echo e($items->total_square_ft); ?></b>
                (Rate): <b><?php echo e($items->rate); ?></b>


            </td>

            <td><?php echo e(number_format($items->price, 2, '.', ',')); ?></td>
            <td>0</td>
            <td><?php echo e(number_format($total_balance, 2, '.', ',')); ?></td>
            <td>
                <?php echo e($transection->calan); ?>

            </td>
            <td>-</td>

            <td>
                <button class="btn btn-success" id="view_invoice" value="<?php echo e($transection->id); ?>" title="View"><i
                        class="fa-regular fa-eye"></i></button>
                <a href="<?php echo e(url('edit-invoice/' . $transection->id)); ?>" class="btn btn-info ml-1" title="Edit"><i
                        class="fa-solid fa-pencil"></i></a>
                <button value="<?php echo e($transection->id); ?>" id="delete_invoice" class="btn btn-danger ml-1" title="Delete"><i
                        class="fa-solid fa-trash"></i></button>
            </td>

        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php

        $total_balance -= $transection->credit;

    ?>



    <tr>

        <td><?php echo e($transection->entry_date); ?></td>
        <td>PAYMENT</td>
        <td> 0 </td>
        <td><?= number_format($transection->credit, 2, '.', ',') ?></td>
        <td><?php echo e(number_format($total_balance, 2, '.', ',')); ?></td>
        <td>-</td>

        <td><?php echo e($transection->bank_name); ?></td>



        <?php if($transection->type == 'INVOICE' && $status == 'view'): ?>
            <td>
                <button class="btn btn-success" id="view_invoice" value="<?php echo e($transection->id); ?>" title="View"><i
                        class="fa-regular fa-eye"></i></button>
                <a href="<?php echo e(url('edit-invoice/' . $transection->id)); ?>" class="btn btn-info ml-1" title="Edit"><i
                        class="fa-solid fa-pencil"></i></a>
                <button value="<?php echo e($transection->id); ?>" id="delete_invoice" class="btn btn-danger ml-1"
                    title="Delete"><i class="fa-solid fa-trash"></i></button>
            </td>
        <?php elseif($transection->type == 'PAYMENT' && $status == 'view'): ?>
            <td>
                <button class="btn btn-success" id="view_invoice" value="<?php echo e($transection->id); ?>" title="View"
                    disabled><i class="fa-regular fa-eye"></i></button>
                <a href="<?php echo e(url('edit-daily_entry/' . $transection->id)); ?>" class="btn btn-info ml-1" title="Edit"><i
                        class="fa-solid fa-pencil"></i></a>
                <button value="<?php echo e($transection->id); ?>" id="delete_entry" class="btn btn-danger ml-1" title="Delete"><i
                        class="fa-solid fa-trash"></i></button>
            </td>
        <?php elseif($transection->type == 'OPENING BALANCE' && $status == 'view'): ?>
            <td>
                <button class="btn btn-success" id="view_invoice" value="<?php echo e($transection->id); ?>" title="View"
                    disabled><i class="fa-regular fa-eye"></i></button>

                <button class="btn btn-info ml-1" id="edit_supplier" value="<?php echo e($transection->ledger_id); ?>"
                    title="Edit Supplier" disabled><i class="fa-solid fa-pencil"></i></button>

                <button value="<?php echo e($transection->id); ?>" id="delete_entry" class="btn btn-danger ml-1" title="Delete"
                    disabled><i class="fa-solid fa-trash"></i></button>
            </td>
        <?php endif; ?>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\1New folder\Invoice\resources\views/view_transection.blade.php ENDPATH**/ ?>