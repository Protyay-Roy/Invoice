<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Download Invoice</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css"
        integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <style>
        table th {
            font-size: 12px !important;
            font-weight: 600 !important;
        }

        table td {
            padding: 0px 5px !important;
            font-size: 11px !important;
        }

        .customer_info td {
            margin-left: 15px
        }

        table thead tr th {
            padding: 0 5px 2px !important
        }
        .table_head{
            background: #1e2896;
            color: #ffffff
        }
    </style>
</head>

<body>
    
    

    
    <div class="row d-flex">
        <div class="col-6">
            logo
        </div>
        <div class="col-6 float-right">
            <p class="pl-1 float-right">Date: <small><?php echo e(date('d-m-y')); ?></small></p>
            <div class="clr"></div>
        </div>
        <div class="clr"></div>
    </div>
    <div class="col-12">
        <table class="ml-2 customer_info">
            <tr>
                <th>Name:</th>
                <td><?php echo e($transections->getCustomer->name); ?></td>
            </tr>
            <tr>
                <th>Email:</th>
                <td><?php echo e($transections->getCustomer->email); ?></td>
            </tr>
            <tr>
                <th>Phone no.:</th>
                <td><?php echo e($transections->getCustomer->phone); ?></td>
            </tr>
            </tr>
        </table>
    </div>
    <table class="table table-bordered mb-3">
        <thead class="table_head">
            <tr>
                <th scope="col">Entry date</th>
                <th scope="col">Item</th>
                <th scope="col">Size</th>
                <th scope="col">Unit</th>
                <th scope="col">Width</th>
                <th scope="col">Height</th>
                <th scope="col">Square ft</th>
                <th scope="col">Rate</th>
                <th scope="col">Amount</th>
            </tr>
        </thead>
        <tbody class="view_tBody">
            <?php $__currentLoopData = $transections->getInvoiceItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice_items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($invoice_items->entry_date); ?></td>
                    <td><?php echo e($invoice_items->item); ?></td>
                    <td><?php echo e($invoice_items->size); ?></td>
                    <td><?php echo e($invoice_items->unit); ?></td>
                    <td><?php echo e($invoice_items->width); ?></td>
                    <td><?php echo e($invoice_items->height); ?></td>
                    <td><?php echo e($invoice_items->square_ft); ?></td>
                    <td><?php echo e($invoice_items->rate); ?></td>
                    <td><?php echo e($invoice_items->price); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <p class="mb-1 mr-1 float-right">Paid: <?php echo e($transections->credit == null ? 0 : $transections->credit); ?>

    </p>
    <div class="clr"></div>
    
</body>

</html>
<?php /**PATH C:\xampp\htdocs\1New folder\Invoice\resources\views/download_pdf.blade.php ENDPATH**/ ?>